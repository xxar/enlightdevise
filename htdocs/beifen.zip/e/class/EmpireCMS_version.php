<?php

define('EmpireCMS_VERSION','7.2');

define('EmpireCMS_CHARVER','UTF-8');

define('EmpireCMS_LASTTIME','201502071030');

define('EmpireCMS_UPDATE','1');

?>